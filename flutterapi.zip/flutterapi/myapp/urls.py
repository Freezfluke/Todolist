from django.urls import path
from .views import * #ดึงมาทุก fuction ของ views.py

urlpatterns = [
    path('', Home),
    path('api/getall-todolist/',all_todolist ),
    path('api/create-todolist', post_todolist),
    path('api/edit-todolist/<int:TID>', edit_todolist),
    path('api/delete-todolist/<int:TID>', delete_todolist)
]
